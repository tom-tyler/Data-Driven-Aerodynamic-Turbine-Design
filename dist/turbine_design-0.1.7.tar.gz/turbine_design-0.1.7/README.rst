turbine_design
=================

**turbine_design** is a Python library for turbine design