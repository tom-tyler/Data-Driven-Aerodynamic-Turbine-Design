"""All code relating to Turbostream lives in this sub-package."""
import os.path

RUN_SCRIPT = os.path.join(os.path.dirname(__file__), "run.sh")
